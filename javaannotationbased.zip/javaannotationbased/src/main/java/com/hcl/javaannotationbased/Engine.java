package com.hcl.javaannotationbased;

public interface Engine 
{
	void rotate();
}
